/**
 * temperature-humidity service
 */

import { factories } from '@strapi/strapi';
import admin from '../../../../config/firebase-admin';

interface TemperatureHumidityData {
  temperature: number | null;
  humidity: number | null;
}

export default factories.createCoreService('api::temperature-humidity.temperature-humidity', {
  lastTemperature: null as number | null,
  lastHumidity: null as number | null,

  async initialize(): Promise<void> {
    const db = admin.database();

    const tempRef = db.ref('currentTemperature');
    tempRef.on('value', async (snapshot) => {
      if (snapshot.exists()) {
        const temperatureValue = snapshot.val() as number;
        console.log(`New temperature: ${temperatureValue}`);
        this.lastTemperature = temperatureValue; // Update last known temperature
        // Only save if both temperature and humidity values are known
        if (this.lastHumidity !== null) {
          await this.saveTemperatureAndHumidity({
            temperature: temperatureValue,
            humidity: this.lastHumidity,
          });
        }
      }
    });

    const humidityRef = db.ref('currentHumidity');
    humidityRef.on('value', async (snapshot) => {
      if (snapshot.exists()) {
        const humidityValue = snapshot.val() as number;
        console.log(`New humidity: ${humidityValue}`);
        this.lastHumidity = humidityValue; // Update last known humidity
        // Only save if both temperature and humidity values are known
        if (this.lastTemperature !== null) {
          await this.saveTemperatureAndHumidity({
            temperature: this.lastTemperature,
            humidity: humidityValue,
          });
        }
      }
    });
  },

  async saveTemperatureAndHumidity(data: TemperatureHumidityData): Promise<void> {
    // Create or update the entry with new data
    const entry = await strapi.entityService.create('api::temperature-humidity.temperature-humidity', { data });

    // Optionally publish the entry if your collection type is set to draft/publish
    await strapi.entityService.update('api::temperature-humidity.temperature-humidity', entry.id, {
      data: {
        publishedAt: new Date(),
      },
    });
  },
});
