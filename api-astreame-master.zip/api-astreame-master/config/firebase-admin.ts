import * as admin from 'firebase-admin';
import serviceAccount from '../qcshs-research-g4-firebase-adminsdk-fxlki-d253e2ccd1.json';

if (admin.apps.length === 0) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount as admin.ServiceAccount),
    databaseURL: process.env.FIREBASE_DB_URL
  });
}

export default admin;
